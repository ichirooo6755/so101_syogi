#pragma once
// USB works without Wi-Fi. Change to 1 to enable the optional camera web server.
#define SHOGI_WIFI_ENABLED 0
// 0: join your 2.4 GHz Wi-Fi. 1: create an access point.
#define SHOGI_AP_MODE 0
#define SHOGI_WIFI_SSID ""
#define SHOGI_WIFI_PASSWORD ""
